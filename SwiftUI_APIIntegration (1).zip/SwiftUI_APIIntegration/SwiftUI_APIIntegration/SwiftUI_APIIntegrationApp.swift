//
//  SwiftUI_APIIntegrationApp.swift
//  SwiftUI_APIIntegration
//
//  Created by Vyshnavi on 23/07/24.
//

import SwiftUI

@main
struct SwiftUI_APIIntegrationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

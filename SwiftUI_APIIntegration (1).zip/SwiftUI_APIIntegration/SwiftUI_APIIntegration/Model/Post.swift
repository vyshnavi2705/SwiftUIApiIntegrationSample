//
//  Post.swift
//  SwiftUI_APIIntegration
//
//  Created by Vyshnavi on 23/07/24.
//

import Foundation

struct Post: Identifiable, Codable {
    let userId: Int
    let id: Int
    let title: String
    let body: String
}
